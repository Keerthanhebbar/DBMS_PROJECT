<?php

     
          include('includes/dbconnection.php');
          $passno=$_GET['PassNumber'];

        
          $sql="DELETE FROM tblpass WHERE PassNumber='$passno' ";

          $query = $dbh -> prepare($sql);
          $query->execute();
          $results=$query->fetchAll(PDO::FETCH_OBJ);


          #$res=mysqli_query($conn,$query);

         
             echo '<script type="text/javascript">';
            echo 'alert("Deleted Successfully");';
            echo 'window.location.href="manage-pass.php";';
            echo '</script>';

?>